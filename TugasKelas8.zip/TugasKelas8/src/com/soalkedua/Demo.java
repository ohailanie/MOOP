package com.soalkedua;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyClassPrime myClassPrime = new MyClassPrime();
		Thread thread = new Thread(myClassPrime);
		thread.start();
		
		MyClassFIbonacci myClassFibonacci = new MyClassFIbonacci();
		Thread thread2 = new Thread(myClassFibonacci);
		thread2.start();
		
		
	}

}

