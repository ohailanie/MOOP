package com.soalkedua;

public class MyClassFIbonacci implements Runnable{

	@Override
	public void run() {
		try {
			Thread.sleep(120000);
			int n = 20, firstNumber = 0, secondNumber = 1;
			System.out.println(n + " Fibonacci's Number: ");

			for (int i = 1; i <= n; ++i) {
				System.out.print(firstNumber + " , "); 
				int sum =  firstNumber + secondNumber;
				firstNumber = secondNumber;
				secondNumber = sum;
			}
		} catch (InterruptedException e) {
	
		}
	}

}

