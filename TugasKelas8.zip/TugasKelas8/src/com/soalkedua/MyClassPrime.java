package com.soalkedua;

public class MyClassPrime implements Runnable {

	@Override
	public void run() {
		System.out.println("Please wait 1 minutes for the results [10 First Prime Number: ");
		try {
			Thread.sleep(60000);
			int n = 30;
	        System.out.println("10 First Prime Numbers are : ");
	        for(int i=2; i<n; i++) {
	            boolean isPrime = true;
	            
	            for (int j = 2; j < i; j++) {
	                if(i%j==0){
	                    isPrime = false;
	                    break;
	                    
	                }
	            }
	            if(isPrime==true){
	                System.out.print(i+" , ");
	            }
	        }
	        System.out.println(" ");
	        System.out.println("Please wait 1 minutes for the results [20 First Prime Number] :");
		} catch (InterruptedException e) {

		}
	}

}
