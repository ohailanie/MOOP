package com.soalpertama;

public class MyClassGanjilGenap implements Runnable {

	int number; 
	
	public MyClassGanjilGenap(int number) {
		// TODO Auto-generated constructor stub
		System.out.println("Just waiting for 30seconds for answer [Odd/Even]!");
		this.number = number;
	}

	@Override
	public void run() {
		try {
			Thread.sleep(30000);
			if(number %2 == 1){
				System.out.println("An Odd Number");
			}
			else{
				System.out.println("An Even Number");
			}
		} catch (InterruptedException e) {
		}
	}
	
}
