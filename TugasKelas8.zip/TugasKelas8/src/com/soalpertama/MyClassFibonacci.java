package com.soalpertama;


public class MyClassFibonacci implements Runnable {
	int number;

	public MyClassFibonacci(int angka) {
		this.number = number;
	}

	@Override
	public void run() {
		int n = 20, firstNumber = 0, secondNumber = 1;
		System.out.println(n + " Fibonacci's number: ");

		for (int i = 1; i <= n; ++i) {
			System.out.print(firstNumber + " ");
			int sum = firstNumber + secondNumber;
			firstNumber = secondNumber;
			secondNumber = sum;

			if (sum != firstNumber + secondNumber && firstNumber != secondNumber && secondNumber != sum) {
				System.out.println("Not a Fibonacci!");
			} else {
				System.out.println("Is A Fibonacci Number!");
			}
		}
		System.out.println("Jika angka yang dimasukan tidak ada, maka angka tersebut bukan bilangan Fibonacci");
	}

}