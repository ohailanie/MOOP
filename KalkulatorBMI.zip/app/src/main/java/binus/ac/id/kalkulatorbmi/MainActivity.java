package binus.ac.id.kalkulatorbmi;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

        private EditText edtTinggiBadan;
        private EditText edtBeratBadan;
        private EditText edtHasil;
        private Button btnHitungBMI;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initUI();
        initEvent();
    }

    private void initUI()
    {
        edtTinggiBadan = (EditText) findViewById(R.id.field1);
        edtBeratBadan = (EditText) findViewById(R.id.field2);
        edtHasil = (EditText) findViewById(R.id.field3);
        btnHitungBMI = (Button) findViewById(R.id.btnhitung);
    }

    private void initEvent()
    {
        btnHitungBMI.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               HitungBMI();
            }
        });
    }

        private void HitungBMI()
        {
            double tinggiBadan = Integer.parseInt(edtTinggiBadan.getText().toString());
            double beratBadan = Integer.parseInt(edtBeratBadan.getText().toString());
            double hasil = beratBadan/(tinggiBadan*tinggiBadan);
            edtHasil.setText(hasil+" ");
        }

}
