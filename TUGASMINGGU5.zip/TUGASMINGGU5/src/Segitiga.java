
public class Segitiga extends BangunDatar{
	private int alas,tinggi,sisi1,sisi2,sisi3;

	@Override
	double luas() {
		double luas = alas * tinggi / 2;
        System.out.println("Luas segitiga adalah : " + luas);
		return super.luas();
	}

	@Override
	double keliling() {
		double keliling = sisi1+sisi2+sisi3;
		System.out.println("Keliling segitiga adalah : " + keliling);
		return super.keliling();
	}

	public int getAlas() {
		return alas;
	}

	public void setAlas(int alas) {
		this.alas = alas;
	}

	public int getTinggi() {
		return tinggi;
	}

	public void setTinggi(int tinggi) {
		this.tinggi = tinggi;
	}

	public int getSisi1() {
		return sisi1;
	}

	public void setSisi1(int sisi1) {
		this.sisi1 = sisi1;
	}

	public int getSisi2() {
		return sisi2;
	}

	public void setSisi2(int sisi2) {
		this.sisi2 = sisi2;
	}

	public int getSisi3() {
		return sisi3;
	}

	public void setSisi3(int sisi3) {
		this.sisi3 = sisi3;
	}

	public Segitiga(int alas, int tinggi, int sisi1, int sisi2, int sisi3) {
		super();
		this.alas = alas;
		this.tinggi = tinggi;
		this.sisi1 = sisi1;
		this.sisi2 = sisi2;
		this.sisi3 = sisi3;
	}
	
	
}
